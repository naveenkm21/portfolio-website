import type { Metadata } from "next"
import Hero from "@/components/hero"
import About from "@/components/about"
import Skills from "@/components/skills"
import Experience from "@/components/experience"
import Projects from "@/components/projects"
import Education from "@/components/education"
import Certifications from "@/components/certifications"
import CodingProfiles from "@/components/coding-profiles"
import Contact from "@/components/contact"
import Footer from "@/components/footer"
import ThemeProvider from "@/components/theme-provider"
import Navbar from "@/components/navbar"

export const metadata: Metadata = {
  title: "Naveen Kumar Mohanarajan | Portfolio",
  description: "Computer Science undergraduate specializing in front-end development and web technologies",
}

export default function Home() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <Hero />
          <About />
          <Skills />
          <Experience />
          <Projects />
          <Education />
          <Certifications />
          <CodingProfiles />
          <Contact />
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  )
}

