"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Award, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

const certifications = [
  {
    title: "IBM - Introduction to Software Engineering",
    issuer: "Coursera",
    date: "2023",
    link: "#",
  },
  {
    title: "Oracle Cloud Infrastructure Foundations",
    issuer: "Coursera",
    date: "2023",
    link: "#",
  },
  {
    title: "Oracle Java Foundations",
    issuer: "Coursera",
    date: "2023",
    link: "#",
  },
  {
    title: "Programming in JAVA",
    issuer: "NPTEL",
    date: "2023",
    link: "#",
  },
  {
    title: "AWS Academy Cloud Foundations",
    issuer: "AWS",
    date: "2023",
    link: "#",
  },
  {
    title: "AWS Academy Cloud Architect",
    issuer: "AWS",
    date: "2023",
    link: "#",
  },
]

export default function Certifications() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="certifications" ref={ref} className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Certifications</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-gray-600">Professional certifications and courses I've completed</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
        >
          {certifications.map((cert, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300 border border-primary/10 hover:border-primary/30 flex items-start gap-4"
            >
              <div className="p-2 bg-primary/10 rounded-lg">
                <Award className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <h3 className="font-bold">{cert.title}</h3>
                <p className="text-gray-600 text-sm mt-1">
                  {cert.issuer} • {cert.date}
                </p>
                {cert.link && (
                  <Button variant="link" size="sm" className="p-0 h-auto mt-2 text-secondary" asChild>
                    <a href={cert.link} target="_blank" rel="noopener noreferrer">
                      View Certificate
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </Button>
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

