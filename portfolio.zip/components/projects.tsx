"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { ExternalLink, Github, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const projects = [
  {
    title: "Gasifier Refractory Life Prediction",
    description:
      "Machine Learning project to predict gasifier refractory lifespan and visualize real-time insights through Power BI dashboards. Enables proactive maintenance, minimizes downtime, and enhances operational efficiency.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Machine Learning", "Power BI", "Data Analysis"],
    github: "https://github.com/naveenkm21",
    demo: null,
    details:
      "This project uses advanced machine learning algorithms to predict the lifespan of gasifier refractories based on operational data. The system analyzes historical performance metrics and current operating conditions to provide accurate predictions. Real-time insights are visualized through interactive Power BI dashboards, allowing operators to monitor performance and schedule maintenance proactively. This approach has significantly reduced unexpected downtime and extended the overall lifespan of refractories.",
  },
  {
    title: "Human Following Robot",
    description:
      "An Arduino-based robot that can detect and follow human movement using ultrasonic sensors and motion detection algorithms.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Arduino", "Robotics", "C++"],
    github: "https://github.com/naveenkm21",
    demo: null,
    details:
      "This project implements a human-following robot using Arduino as the main controller. The robot uses ultrasonic sensors to detect obstacles and a combination of IR sensors to detect and track human movement. The control algorithms are written in C++ and optimize the robot's movement to maintain a consistent following distance while avoiding obstacles. The project demonstrates practical applications of embedded systems programming and sensor integration in robotics.",
  },
  {
    title: "Unscramble Mobile App",
    description:
      "Android word game app that challenges users to unscramble jumbled words within a time limit, featuring multiple difficulty levels and a scoring system.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Android Studio", "Java", "Mobile Development"],
    github: "https://github.com/naveenkm21",
    demo: null,
    details:
      "The Unscramble Mobile App is a word puzzle game developed for Android using Android Studio and Java. The app features multiple difficulty levels, a comprehensive word database, and an intuitive user interface. Players are presented with scrambled words and must rearrange the letters to form the correct word within a time limit. The game includes a scoring system that rewards quick solutions and consecutive correct answers. Additional features include sound effects, animations, and a leaderboard to track high scores.",
  },
  {
    title: "Online Exam Web Application",
    description:
      "A comprehensive web platform for conducting online examinations with features like automatic grading, timed tests, and result analytics.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["HTML", "CSS", "JavaScript", "Web Development"],
    github: "https://github.com/naveenkm21",
    demo: null,
    details:
      "The Online Exam Web Application is a full-featured platform designed to facilitate remote testing and assessment. Built with HTML, CSS, and JavaScript, the application provides a secure environment for conducting exams with features such as randomized question selection, time constraints, and automatic grading. The system includes an admin panel for creating and managing exams, a student dashboard for taking tests, and comprehensive analytics for reviewing performance. Security features include browser lockdown and anti-cheating measures to maintain exam integrity.",
  },
  {
    title: "Stock Price Predictor",
    description:
      "A machine learning application that analyzes historical stock data to predict future price movements using time series analysis and regression models.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Python", "Machine Learning", "Data Analysis"],
    github: "https://github.com/naveenkm21",
    demo: null,
    details:
      "The Stock Price Predictor is a Python-based application that leverages machine learning algorithms to forecast stock price movements. The system processes historical stock data, performs feature engineering to extract relevant indicators, and applies various prediction models including LSTM networks and regression algorithms. The application includes data visualization components to help users interpret predictions and understand market trends. While not designed for financial advice, the project demonstrates practical applications of time series analysis and predictive modeling in financial markets.",
  },
]

export default function Projects() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [selectedProject, setSelectedProject] = useState(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  const openProjectDetails = (project) => {
    setSelectedProject(project)
    setIsDialogOpen(true)
  }

  return (
    <section id="projects" ref={ref} className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">My Projects</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-gray-600">A showcase of my technical projects and applications</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group bg-white border border-gray-200 rounded-xl overflow-hidden border border-primary/10 hover:border-primary/30 shadow-sm hover:shadow-md transition-all duration-300"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, i) => (
                    <span key={i} className="text-xs px-2 py-1 rounded-full bg-primary/10 text-secondary">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    {project.github && (
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-full bg-muted hover:bg-muted/80 transition-colors"
                      >
                        <Github className="h-4 w-4" />
                        <span className="sr-only">GitHub</span>
                      </a>
                    )}
                    {project.demo && (
                      <a
                        href={project.demo}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-full bg-muted hover:bg-muted/80 transition-colors"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span className="sr-only">Live Demo</span>
                      </a>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-secondary"
                    onClick={() => openProjectDetails(project)}
                  >
                    Details
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        {selectedProject && (
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedProject.title}</DialogTitle>
              <DialogDescription>
                <div className="mt-4 aspect-video overflow-hidden rounded-lg">
                  <img
                    src={selectedProject.image || "/placeholder.svg"}
                    alt={selectedProject.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Technologies</h4>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedProject.tags.map((tag, i) => (
                      <span key={i} className="text-xs px-2 py-1 rounded-full bg-primary/10 text-secondary">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h4 className="text-sm font-medium mb-2">Description</h4>
                  <p className="text-sm text-gray-600 mb-4">{selectedProject.details || selectedProject.description}</p>
                  <div className="flex gap-4">
                    {selectedProject.github && (
                      <Button asChild variant="outline" size="sm">
                        <a href={selectedProject.github} target="_blank" rel="noopener noreferrer">
                          <Github className="mr-2 h-4 w-4" />
                          View on GitHub
                        </a>
                      </Button>
                    )}
                    {selectedProject.demo && (
                      <Button asChild size="sm">
                        <a href={selectedProject.demo} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="mr-2 h-4 w-4" />
                          Live Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </DialogDescription>
            </DialogHeader>
          </DialogContent>
        )}
      </Dialog>
    </section>
  )
}

