"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { GraduationCap, Calendar } from "lucide-react"

const education = [
  {
    institution: "S.R.M Institute of Science And Technology",
    degree: "B.Tech: Computer Engineering",
    location: "Chennai, Tamil Nadu",
    period: "Expected in December 2027",
  },
  {
    institution: "K.D.Ambani Reliance Foundation School",
    degree: "10TH & 12TH Class",
    location: "Jamnagar, Gujarat",
    period: "April 2023",
  },
]

export default function Education() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="education" ref={ref} className="py-20 bg-gray-50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Education</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-gray-600">My academic background and qualifications</p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            className="space-y-8"
          >
            {education.map((edu, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border flex flex-col md:flex-row gap-6"
              >
                <div className="flex-shrink-0 flex items-start justify-center">
                  <div className="p-3 bg-secondary/10 rounded-full">
                    <GraduationCap className="h-8 w-8 text-secondary" />
                  </div>
                </div>
                <div className="flex-grow">
                  <h3 className="text-xl font-bold">{edu.institution}</h3>
                  <p className="text-secondary font-medium mt-1">{edu.degree}</p>
                  <p className="text-gray-600 mt-1">{edu.location}</p>
                  <div className="flex items-center mt-3 text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-2" />
                    {edu.period}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}

