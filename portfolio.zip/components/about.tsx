"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const variants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0 },
  }

  return (
    <section id="about" ref={ref} className="py-20 bg-white">
      <div className="container">
        <motion.div
          variants={variants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">About Me</h2>
          <div className="section-divider mb-8"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
          <motion.div
            variants={variants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-2xl overflow-hidden bg-muted">
              <img
                src="/placeholder.svg?height=600&width=600"
                alt="Naveen Kumar Mohanarajan"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full"></div>
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-primary/10 rounded-full"></div>
          </motion.div>

          <motion.div
            variants={variants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-bold">Professional Summary</h3>
            <p className="text-gray-600">
              Highly motivated Computer Science undergraduate with a strong foundation in C and C++. Seeking
              opportunities to enhance skills in front-end development and web technologies. Passionate about continuous
              learning and utilizing new abilities to create dynamic user interfaces and innovative web solutions.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium">Name</h4>
                <p className="text-gray-600">Naveen Kumar Mohanarajan</p>
              </div>
              <div>
                <h4 className="font-medium">Email</h4>
                <p className="text-gray-600">naveenkumarmohanarajan38@gmail.com</p>
              </div>
              <div>
                <h4 className="font-medium">Location</h4>
                <p className="text-gray-600">Chennai, Tamil Nadu</p>
              </div>
              <div>
                <h4 className="font-medium">Phone</h4>
                <p className="text-gray-600">+91 9106663529</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

