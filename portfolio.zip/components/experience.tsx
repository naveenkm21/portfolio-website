"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Briefcase } from "lucide-react"

const experiences = [
  {
    company: "Reliance Industries Limited",
    position: "Intern",
    period: "December 2024 - January 2025",
    description:
      "Contributed to a Machine Learning project predicting gasifier refractory lifespan and visualizing real-time insights through Power BI dashboards. This enabled proactive maintenance, minimized downtime, and enhanced operational efficiency.",
  },
  {
    company: "AICTE - EDUSKILLS",
    position: "Intern",
    period: "October 2024 - December 2024",
    description:
      "Contributed to Android app development using Jetpack Compose, focusing on feature implementation, performance optimization, and user-friendly solutions.",
  },
  {
    company: "PERSONIFWY",
    position: "Intern",
    period: "May 2024 - June 2024",
    description:
      "Completed a 6-week Artificial Intelligence internship, gaining hands-on AI experience and contributing effectively. Recognized for dedication and hard work.",
  },
]

export default function Experience() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="experience" ref={ref} className="py-20 bg-gray-50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Work Experience</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-gray-600">My professional journey and internship experiences</p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            className="relative border-l border-primary/30 pl-8 ml-4"
          >
            {experiences.map((exp, index) => (
              <motion.div key={index} variants={itemVariants} className="mb-12 relative">
                <div className="absolute -left-12 mt-1.5 flex items-center justify-center w-8 h-8 rounded-full bg-primary text-secondary shadow-md">
                  <Briefcase className="h-4 w-4" />
                </div>
                <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border">
                  <h3 className="text-xl font-bold">{exp.company}</h3>
                  <div className="flex flex-wrap items-center gap-2 mt-1 mb-3">
                    <span className="text-sm font-medium text-secondary">{exp.position}</span>
                    <span className="text-sm text-gray-600">{exp.period}</span>
                  </div>
                  <p className="text-gray-600">{exp.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}

