"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Mail, Phone, MapPin, Github, Linkedin } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Contact() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="contact" ref={ref} className="py-20 bg-white">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4 text-black">Get In Touch</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-muted-foreground">Have a question or want to work together? Feel free to contact me!</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="max-w-2xl mx-auto"
        >
          <motion.div variants={itemVariants} className="space-y-8">
            <div className="flex items-start">
              <div className="p-2 bg-accent rounded-lg mr-4">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="font-medium text-black">Email</h4>
                <p className="text-muted-foreground">naveenkumarmohanarajan38@gmail.com</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="p-2 bg-accent rounded-lg mr-4">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="font-medium text-black">Phone</h4>
                <p className="text-muted-foreground">+91 9106663529</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="p-2 bg-accent rounded-lg mr-4">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="font-medium text-black">Location</h4>
                <p className="text-muted-foreground">Chennai, Tamil Nadu, India</p>
              </div>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="mt-12">
            <h3 className="text-xl font-bold mb-4 text-black">Connect with me</h3>
            <div className="flex justify-center gap-4">
              <Button asChild variant="outline" size="lg">
                <a href="https://github.com/naveenkm21" target="_blank" rel="noopener noreferrer">
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="https://www.linkedin.com/in/naveenkumarmohanarajan/" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="mr-2 h-4 w-4" />
                  LinkedIn
                </a>
              </Button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

