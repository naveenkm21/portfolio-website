"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Code, Database, Cpu, BarChart3, Globe, Layers } from "lucide-react"

const skills = [
  {
    category: "Programming Languages",
    icon: Code,
    items: ["C/C++", "Java", "Python", "JavaScript"],
  },
  {
    category: "Web Technologies",
    icon: Globe,
    items: ["HTML", "CSS", "JavaScript"],
  },
  {
    category: "AI & Machine Learning",
    icon: Cpu,
    items: ["Machine Learning", "Data Analysis", "Model Training"],
  },
  {
    category: "Data Visualization",
    icon: BarChart3,
    items: ["Power BI", "Data Interpretation", "Dashboard Creation"],
  },
  {
    category: "Databases",
    icon: Database,
    items: ["SQL", "Database Design", "Data Management"],
  },
  {
    category: "Development Tools",
    icon: Layers,
    items: ["Git", "Android Studio", "VS Code", "Arduino"],
  },
]

export default function Skills() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="skills" ref={ref} className="py-20">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">My Skills</h2>
          <div className="section-divider mb-8"></div>
          <p className="text-gray-600">A comprehensive overview of my technical expertise and capabilities</p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {skills.map((skill, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300 border border-primary/10 hover:border-primary/30"
            >
              <div className="flex items-center mb-4">
                <div className="p-2 bg-primary/10 rounded-lg mr-4">
                  <skill.icon className="h-6 w-6 text-secondary" />
                </div>
                <h3 className="text-xl font-bold">{skill.category}</h3>
              </div>
              <ul className="space-y-2">
                {skill.items.map((item, i) => (
                  <li key={i} className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-secondary mr-3"></div>
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

